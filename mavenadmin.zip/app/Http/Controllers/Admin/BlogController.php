<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;


use App\Models\Notification;


use Yajra\Datatables\Datatables;


use DB;
class BlogController extends Controller
{
    /**
     * Function name : index
     * Parameter : null
     * task : show all country list
     * auther : Manish Silawat
     */   
    public function index() {

        $data['active_link'] = 'blog';
        return view('admin.bloglist', $data);
    }
    
  
  public function blog(){
    $data['active_link'] = 'blog'; 
    // $data['category'] = DB::table('categories')->where('status', 'Active')->get();
    return view('admin.blog',$data);
  }

public function addblog (Request $request){
  
  $title=$request->post('title');
  $category=$request->post('blogcategory');
  $thumbnail=$request->post('thumbnail');
  $blogimage=$request->post('blogimage');
  $blogvideo=$request->post('blogvideo');
  $blogcontent=$request->post('content');
  $status=$request->post('status');

  
  $thumb = '';
		if ($thumbnail) {
			$destinationPath = 'public/system/courses/';
			$file_name = time() . "." . $thumbnail->getClientOriginalExtension();
			$thumbnail->move($destinationPath, $file_name);
			$thumb.=$file_name;
		}
    $mainThumb = '';
		if ($blogvideo) {
			$destinationPath = 'public/system/courses/';
			$file_name = time() . "." . $blogvideo->getClientOriginalExtension();
			$blogvideo->move($destinationPath, $file_name);
			$mainThumb.=$file_name;
		}
    $data = [
      'title'   => $title,
      'blogcategory'   => $category,
       'thumbnail'   => $thumbnail,
       'blogimage'   => $blogimage,
       'blogvideo'   => $blogvideo,
       'content'   => $blogcontent,
       'status'  => $status,

    ];
  
		$adduser =DB::table('blog')->insert($data);
    return redirect()->route('admin.blogindex')->with('success','Blog Added successfully.');
  }
  



  public function editblog($id) {
    $data['active_link'] = 'bloglist';
    $data['blogInfo'] = DB::table('blog')->where('id', $id)->first(); 
//   $data['category'] = DB::table('categories')->where('status', 'Active')->get();
    return view('admin.editblog', $data);
  }

  public function updateBlog(Request $request, $id) {
    $title=$request->post('title');
    $category=$request->post('blogcategory');
    $thumbnail=$request->post('thumbnail');
    $blogimage=$request->post('blogimage');
    $blogvideo=$request->post('blogvideo');
    $blogcontent=$request->post('content');
    $status=$request->post('status');

       $getblog = DB::table('blog')->where('id', $id)->select('title','blogcategory','thumbnail','blogimage','blogvideo','content')->first();

       $thumb = '';
       if ($thumbnail) {
         $destinationPath = 'public/system/courses/';
         $file_name = time() . "." . $thumbnail->getClientOriginalExtension();
         $thumbnail->move($destinationPath, $file_name);
         $thumb.=$file_name;
       }else{
        $thumb = isset($getblog) ? $getblog->thumbnail : '';
       }
       $mainThumb = '';
       if ($blogvideo) {
         $destinationPath = 'public/system/courses/';
         $file_name = time() . "." . $blogvideo->getClientOriginalExtension();
         $blogvideo->move($destinationPath, $file_name);
         $mainThumb.=$file_name;
       }else{
        $thumb = isset($getblog) ? $getblog->blogvideo: '';
       }
       $data = [
         'title'   => $title,
         'blogcategory'   => $category,
          'thumbnail'   => $thumbnail,
          'blogimage'   => $blogimage,
          'blogvideo'   => $blogvideo,
          'content'   => $blogcontent,
          'status'  => $status,

          
       ];
       DB::table('blog')->where('id', $id)->update($data);

       return redirect()->route('admin.blogindex')->with('success','  blog updated successfully.');
     
     
  }


public function ajaxBlogList() {

  return Datatables::of( DB::table('blog')->orderBy('id', 'DESC')->get())
  ->addColumn('action', function($data) {
    $data->deleteMsg = 'Are you sure want to delete ?';
    $button = '<a href="'.route('admin.editblog', [$data->id]).'" id="'.$data->id.'" class="btn btn-info btn-sm" title="Edit Blog"><i class="far fa-edit"></i></a>';
    $button .='&nbsp;&nbsp;';
    $button .='<a href="'.route('admin.deleteblog', [$data->id]).'" id="'.$data->id.'" class="btn btn-danger btn-sm" onclick="return confirm('."'".$data->deleteMsg."'".');" title="Delete Blog" ><i class="fas fa-trash-alt"></i></a>';
    $button .='&nbsp;&nbsp;';

    if($data->status == 'Active') {
      $iconClass = 'fas fa-lock';
      $statusClass = 'btn btn-success btn-sm';
      $statusTitle = 'Inactive Blog';
      $data->statusMsg = 'Are you sure want to inactivate Blog '.$data->title.' ?';

    } else {
      $iconClass = 'fas fa-lock-open';
      $statusClass = 'btn btn-danger btn-sm';
      $statusTitle = 'Active Blog';
      $data->statusMsg = 'Are you sure want to change status ?';
      $data->statusMsg = 'Are you sure want to activate Blog '.$data->title.' ?';
    }

    $button .='<a href="'.route('admin.changeStatusblog', [$data->id, $data->status]).'" id="'.$data->id.'" class="'.$statusClass.'" onclick="return confirm('."'".$data->statusMsg."'".');" title="'.$statusTitle.'" ><i class="'.$iconClass.'"></i></a>';
    
    return $button; 
  })->rawColumns(['action'])
  ->make(true);
  // return view('admin.bloglist',$data);
}

public function deleteblog($id) {
      
  DB::table('blog')->where('id', $id)->delete();

  return back()->with('success','blog deleted successfully.');

}

public function changeStatusblog($id, $status) {
  if($status == 'Inactive') {
    $updateField = 'Active';
  } else {
    $updateField = 'Inactive';
  }

  DB::table('blog')->where('id', $id)->update([
    'status' => $updateField
  ]);

  return back()->with('success','blog status updated successfully.');

}



}