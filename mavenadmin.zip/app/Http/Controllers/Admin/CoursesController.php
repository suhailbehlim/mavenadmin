<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Yajra\Datatables\Datatables;


use App\Models\User;
use App\Models\Country;
use App\Models\State;
use App\Models\City;


use App\Exports\UsersExport;

use Hash;
use DB;


class CoursesController extends Controller
{
    public function index() {
        $data['active_link'] = 'courses-list'; 
        return view('admin.courses.list', $data);
    }
	
    public function ajaxCoursesList() {
        return Datatables::of( DB::table('courses')->orderBy('id', 'DESC')->get())
        ->addColumn('action', function($data) {
        	$data->deleteMsg = 'Are you sure want to delete ?';
        	$button = '<a href="'.route('admin.editCourse', [$data->id]).'" id="'.$data->id.'" class="btn btn-info btn-sm" title="Edit Course"><i class="far fa-edit"></i></a>';
        	$button .='&nbsp;&nbsp;';
        	$button .='<a href="'.route('admin.deleteCourse', [$data->id]).'" id="'.$data->id.'" class="btn btn-danger btn-sm" onclick="return confirm('."'".$data->deleteMsg."'".');" title="Delete Course" ><i class="fas fa-trash-alt"></i></a>';
			$button .='&nbsp;&nbsp;';

          if($data->status == 'Active') {
            $iconClass = 'fas fa-lock';
            $statusClass = 'btn btn-success btn-sm';
            $statusTitle = 'Inactive Course';
            $data->statusMsg = 'Are you sure want to inactivate Course '.$data->title.' ?';

          } else {
            $iconClass = 'fas fa-lock-open';
            $statusClass = 'btn btn-danger btn-sm';
            $statusTitle = 'Active Course';
            $data->statusMsg = 'Are you sure want to change status ?';
            $data->statusMsg = 'Are you sure want to activate Course '.$data->title.' ?';
          }

        	$button .='<a href="'.route('admin.changeStatusCourse', [$data->id, $data->status]).'" id="'.$data->id.'" class="'.$statusClass.'" onclick="return confirm('."'".$data->statusMsg."'".');" title="'.$statusTitle.'" ><i class="'.$iconClass.'"></i></a>';
        	
        	return $button;  
        })->rawColumns(['action'])
        ->make(true);
	  }

	
    public function exportExcel($type) {
        return \Excel::download(new UsersExport, 'users.'.$type);
    }
    
	public function deleteCourse($id) {
      
      DB::table('courses')->where('id', $id)->delete();

      return back()->with('success','Course deleted successfully.');

    }

    public function changeStatusCourse($id, $status) {
      if($status == 'Inactive') {
        $updateField = 'Active';
      } else {
        $updateField = 'Inactive';
      }

      DB::table('courses')->where('id', $id)->update([
        'status' => $updateField
      ]);

      return back()->with('success','Course status updated successfully.');

    }    
         
    public function addCourse() {
      $data['active_link'] = 'courses-list'; 
	  $data['category'] = DB::table('categories')->get();
      return view('admin.courses.add',$data);
    }

    public function storeCourse(Request $request) {
      $request->validate([
        'course_type'        => 'required|min:2',
        'category'             => 'required',
        'title'          => 'required',

      ]);
		$course_type=$request->post('course_type');
		$category=$request->post('category');
		// $level=$request->post('level');
		$languages=$request->post('languages');
        $title=$request->post('title');
		$timing=$request->post('timing');
        $requirements=$request->post('requirements');
		$short_description=$request->post('short_description');
		$full_description=$request->post('full_description');
		$subscription=$request->post('subscription');
		$price=$request->post('price');
		$batch=$request->post('batch');
		$offer=$request->post('offer');
		$thumbnail = $request->file('thumbnail');
		$main_image = $request->file('main_image');
		$shortvideo = $request->file('shorts');
		$fullvideo = $request->file('fullvideo');
		$status=$request->post('status');
		$date = date("Y-m-d H:i:s", time());
		$thumb = '';
		if ($thumbnail) {
			$destinationPath = 'public/system/courses/';
			$file_name = time() . "." . $thumbnail->getClientOriginalExtension();
			$thumbnail->move($destinationPath, $file_name);
			$thumb.=$file_name;
		}
		$mainThumb = '';
		if ($main_image) {
			$destinationPath = 'public/system/courses/';
			$file_name = time() . "." . $main_image->getClientOriginalExtension();
			$main_image->move($destinationPath, $file_name);
			$mainThumb.=$file_name;
		}
		$shortvideo='';
		if ($shortvideo) {
			$destinationPath = 'public/system/courses/';
			$file_name = time() . "." . $shortvideo->getClientOriginalExtension();
			$shortvideo->move($destinationPath, $file_name);
			$shortvideo.=$file_name;
		}
		$mainThumb = '';
		if ($fullvideo) {
			$destinationPath = 'public/system/courses/';
			$file_name = time() . "." . $fullvideo->getClientOriginalExtension();
			$fullvideo->move($destinationPath, $file_name);
			$fullvideo.=$file_name;
		}
		$data = [
			'course_type' => trim($course_type),
			'category'   => $category, 
			// 'level'      => trim($level),
			'languages'   => trim($languages),
			'title'   => trim($title),
			'batch' => $batch,
			'timing' => $timing,
			'requirements'    => trim($requirements),
			'short_description'    => trim($short_description),
			'full_description'   => $full_description,
			'subscription'   => $subscription,
			'price'   => $price,
			'offer' => $offer,
			'thumbnail'   => $thumb,
			'main_image'   => $mainThumb,
			'shorts'   => $shortvideo,
			'fullvideo' => $fullvideo,
			'status'  => $status,
			'created_at'  => $date,
			'updated_at'  => $date,
		];
		$adduser =DB::table('courses')->insert($data);
		$id = DB::getPdo()->lastInsertId();

		DB::table('courses')->where('id', $id)->update([
			'course_id'  => 'UN0000'.$id
		]);
		return redirect()->route('admin.courses')->with('success','Course added successfully.');

    }

    public function editCourse($id) {
      $data['active_link'] = 'courses-list';
      $data['courseInfo'] = DB::table('courses')->where('id', $id)->first(); 
	  $data['category'] = DB::table('categories')->where('status', 'Active')->get();
      return view('admin.courses.edit', $data);
    }
 
    public function updateCourse(Request $request, $id) {

      $request->validate([
        'course_type'        => 'required|min:2',
        'category'             => 'required',
        'title'          => 'required',

      ]);
		$course_type=$request->post('course_type');
		$category=$request->post('category');
		// $level=$request->post('level');
		$languages=$request->post('languages');
        $title=$request->post('title');
		$batch=$request->post('batch');
		$timing=$request->post('timing');
        $requirements=$request->post('requirements');
		$short_description=$request->post('short_description');
		$full_description=$request->post('full_description');
		$subscription=$request->post('subscription');
		$price=$request->post('price');
		$offer=$request->post('offer');
		$thumbnail = $request->file('thumbnail');
		$shortvideo = $request->file('shorts');
		$fullvideo = $request->file('fullvideo');
		$main_image = $request->file('main_image');
		$status=$request->post('status');
		$date = date("Y-m-d H:i:s", time());
		$getcourse = DB::table('courses')->where('id', $id)->select('thumbnail','main_image','shorts','fullvideo')->first();
		
		if ($thumbnail) {
			$destinationPath = 'public/system/courses/';
			$file_name = time() . "." . $thumbnail->getClientOriginalExtension();
			$thumbnail->move($destinationPath, $file_name);
			$thumb =$file_name;
		}else{
			$thumb = isset($getcourse) ? $getcourse->thumbnail : '';
		}
		if ($main_image) {
			$destinationPath = 'public/system/courses/';
			$file_name = time() . "." . $main_image->getClientOriginalExtension();
			$main_image->move($destinationPath, $file_name);
			$mainThumb=$file_name;
		}else{
			$mainThumb = isset($getcourse) ? $getcourse->main_image : '';
		}
		if ($shortvideo) {
			$destinationPath = 'public/system/courses/';
			$file_name = time() . "." . $shortvideo->getClientOriginalExtension();
			$shortvideo->move($destinationPath, $file_name);
			$shorts =$file_name;
		}else{
			$shorts = isset($getcourse) ? $getcourse->shorts : '';
		}
		if ($fullvideo) {
			$destinationPath = 'public/system/courses/';
			$file_name = time() . "." . $fullvideo->getClientOriginalExtension();
			$fullvideo->move($destinationPath, $file_name);
			$fullvideo=$file_name;
		}else{
			$fullvideo = isset($getcourse) ? $getcourse->fullvideo : '';
		}
		
		$data = [
			'course_type' => trim($course_type),
			'category'   => $category, 
			// 'level'      => trim($level),
			'languages'   => trim($languages),
			'title'   => trim($title),
			'requirements'    => trim($requirements),
			'short_description'    => trim($short_description),
			'full_description'   => $full_description,
			'subscription'   => $subscription,
			'price'   => $price,
			'timing'  => $timing,
			'batch'   => $batch,
			'offer'  => $offer,
			'thumbnail'   => $thumb,
			'shorts'   => $shortvideo,
			'fullvideo' => $fullvideo,
			'main_image'   => $mainThumb,
			'status'  => $status,
			'created_at'  => $date,
			'updated_at'  => $date,
		];
		DB::table('courses')->where('id', $id)->update($data);
  
      return redirect()->route('admin.courses')->with('success','Course updated successfully.');
    }
}




